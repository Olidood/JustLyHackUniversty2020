Place here all api and services

This folder will be parsed by Fastify