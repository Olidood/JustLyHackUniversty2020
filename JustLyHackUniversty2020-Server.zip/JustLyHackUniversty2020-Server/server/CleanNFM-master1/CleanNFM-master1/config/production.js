module.exports = {
  title: "CleanNSFM",
  code: "cleannsfm",
  process: "",
  description: "",
  web_scheme: "https",
  web_host: "localhost",
  web_port: 10010,
  mongo_connection_string: "mongodb://127.0.0.1/__DATABASE__",
  version: "0.1.0",
  uploads_url: "",
};
